create definer = root@localhost trigger restar_stock_producto
    after insert
    on detalleventa
    for each row
BEGIN
  -- Verifica si el producto existe en la tabla productos
  IF EXISTS (SELECT 1 FROM productos WHERE ID = NEW.IDProducto) THEN
    -- Actualiza la cantidad del producto restando la cantidad comprada en detalleventa
    UPDATE productos 
    SET Cantidad = Cantidad - NEW.Cantidad
    WHERE ID = NEW.IDProducto;
  END IF;
END;

