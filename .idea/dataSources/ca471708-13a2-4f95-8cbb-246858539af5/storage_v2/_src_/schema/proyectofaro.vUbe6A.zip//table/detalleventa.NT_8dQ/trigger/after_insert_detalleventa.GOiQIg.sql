create definer = root@localhost trigger after_insert_detalleventa
    after insert
    on detalleventa
    for each row
BEGIN
    DECLARE max_linea INT DEFAULT 0;
    
    -- Buscar el valor máximo de la línea para el IDVenta dado
    SELECT IFNULL(MAX(Linea), 0) INTO max_linea 
    FROM remitos 
    WHERE IDVenta = NEW.IDVenta;

    -- Insertar un nuevo remito con la línea incrementada
    INSERT INTO remitos (
        IDVenta, 
        Linea, 
        FechaEntrega, 
        IDCliente, 
        NombreCliente, 
        CUITCliente, 
        DetalleProducto, 
        Cantidad
    ) 
    SELECT 
        v.ID, 
        max_linea + 1, 
        NULL,  -- O el campo que corresponda para la fecha de entrega
        v.IDCliente, 
        c.Nombre, 
        c.CUIT, 
        NEW.DetalleProducto, 
        NEW.Cantidad
    FROM ventas v
    JOIN clientes c ON v.IDCliente = c.ID
    WHERE v.ID = NEW.IDVenta;

END;

