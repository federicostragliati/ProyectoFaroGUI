create definer = root@localhost trigger revertir_stock_al_anular_venta
    after update
    on ventas
    for each row
BEGIN
  -- Verificar que "Activo" cambió de TRUE a FALSE
  IF OLD.Activo = 1 AND NEW.Activo = 0 THEN
    -- Sumar la cantidad de productos basándose en el detalle de la venta
    UPDATE productos p
    JOIN detalleventa d ON p.ID = d.IDProducto
    SET p.Cantidad = p.Cantidad + d.Cantidad
    WHERE d.IDVenta = NEW.ID;
  END IF;
END;

