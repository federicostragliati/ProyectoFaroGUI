create definer = root@localhost trigger update_recibo
    after update
    on ventas
    for each row
BEGIN
    DECLARE metodo_pago_primario_nombre VARCHAR(100);
    DECLARE metodo_pago_secundario_nombre VARCHAR(100);

    -- Obtener los nombres actualizados de los métodos de pago
    SELECT Nombre INTO metodo_pago_primario_nombre
    FROM metodosdepago
    WHERE ID = NEW.MetodoPagoPrimario;

    SELECT Nombre INTO metodo_pago_secundario_nombre
    FROM metodosdepago
    WHERE ID = NEW.MetodoPagoSecundario;

    -- Actualizar el recibo con los datos modificados
    UPDATE recibos
    SET 
        FechaRecibo = CURDATE(),  -- Actualiza la fecha del recibo a la fecha actual
        FechadePago = NEW.FechaVenta,
        DetalleMetodoPrimario = metodo_pago_primario_nombre,
        MontodePagoPrimario = NEW.MontoPagoPrimario,
        DetalleMetodoSecundario = metodo_pago_secundario_nombre,
        MontoPagoSecundario = NEW.MontoPagoSecundario,
        MontoFinal = NEW.MontoFinal
    WHERE IDVenta = NEW.ID;

END;

