create definer = root@localhost trigger actualizar_stock_al_insertar_detallecompra
    after insert
    on detallecompra
    for each row
BEGIN
  -- Solo actualiza el stock si la compra ha sido entregada
  IF (SELECT Entregado FROM compras WHERE ID = NEW.IDCompra) = 1 THEN
    -- Actualizar la cantidad de productos basándose en el detalle de la compra
    UPDATE productos p
    JOIN detallecompra d ON p.ID = d.IDProducto
    SET p.Cantidad = p.Cantidad + NEW.Cantidad
    WHERE d.IDCompra = NEW.IDCompra AND p.ID = NEW.IDProducto;
  END IF;
END;

