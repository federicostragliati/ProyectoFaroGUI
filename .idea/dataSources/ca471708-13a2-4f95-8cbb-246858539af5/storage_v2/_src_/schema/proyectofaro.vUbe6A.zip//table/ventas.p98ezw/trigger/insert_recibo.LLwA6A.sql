create definer = root@localhost trigger insert_recibo
    after insert
    on ventas
    for each row
BEGIN
    DECLARE cliente_nombre VARCHAR(100);
    DECLARE cliente_cuit VARCHAR(13);
    DECLARE metodo_pago_primario_nombre VARCHAR(100);
    DECLARE metodo_pago_secundario_nombre VARCHAR(100);

    -- Obtener el nombre y CUIT del cliente
    SELECT Nombre, CUIT INTO cliente_nombre, cliente_cuit
    FROM clientes
    WHERE ID = NEW.IDCliente;

    -- Obtener los nombres de los métodos de pago
    SELECT Nombre INTO metodo_pago_primario_nombre
    FROM metodosdepago
    WHERE ID = NEW.MetodoPagoPrimario;

    SELECT Nombre INTO metodo_pago_secundario_nombre
    FROM metodosdepago
    WHERE ID = NEW.MetodoPagoSecundario;

    -- Insertar en la tabla recibos
    INSERT INTO recibos (ID, IDVenta, FechaRecibo, IDCliente, NombreCliente, CUITCliente, FechadePago, NroFactura, DetalleMetodoPrimario, MontodePagoPrimario, DetalleMetodoSecundario, MontoPagoSecundario, MontoFinal)
    VALUES (NEW.ID, NEW.ID, CURDATE(), NEW.IDCliente, cliente_nombre, cliente_cuit, NULL, NULL, metodo_pago_primario_nombre, NEW.MontoPagoPrimario, metodo_pago_secundario_nombre, NEW.MontoPagoSecundario, NEW.MontoFinal);
END;

