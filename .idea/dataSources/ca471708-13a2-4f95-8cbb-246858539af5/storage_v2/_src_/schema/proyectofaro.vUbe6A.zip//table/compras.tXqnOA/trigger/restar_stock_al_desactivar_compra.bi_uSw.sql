create definer = root@localhost trigger restar_stock_al_desactivar_compra
    after update
    on compras
    for each row
BEGIN
  -- Verificar que "Activo" cambió de TRUE a FALSE y "Entregado" es TRUE
  IF OLD.Activo = 1 AND NEW.Activo = 0 AND OLD.Entregado = 1 THEN
    -- Restar la cantidad de productos basándose en el detalle de la compra
    UPDATE productos p
    JOIN detallecompra d ON p.ID = d.IDProducto
    SET p.Cantidad = p.Cantidad - d.Cantidad
    WHERE d.IDCompra = NEW.ID;
  END IF;
END;

