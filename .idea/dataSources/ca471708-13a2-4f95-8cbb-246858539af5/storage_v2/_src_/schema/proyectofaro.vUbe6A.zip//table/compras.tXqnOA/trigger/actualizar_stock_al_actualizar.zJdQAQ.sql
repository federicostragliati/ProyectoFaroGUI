create definer = root@localhost trigger actualizar_stock_al_actualizar
    after update
    on compras
    for each row
BEGIN
  -- Solo ejecuta el trigger si el campo "Entregado" cambia de FALSE a TRUE
  IF OLD.Entregado = 0 AND NEW.Entregado = 1 THEN
    -- Actualizar la cantidad de productos basándose en el detalle de la compra
    UPDATE productos p
    JOIN detallecompra d ON p.ID = d.IDProducto
    SET p.Cantidad = p.Cantidad + d.Cantidad
    WHERE d.IDCompra = NEW.ID;
  END IF;
END;

